void code_checker();

#if !__VS_SYSTEM
#include "defines/charmap/bgm_charmap.h"
#endif
#include "music_soundTestTables.h"
#include "sfx_soundTestTables.h"

const unsigned char bgmtestscreen[];
//const char TEXT_debug_mode[];

void state_soundtest() {
  	famistudio_music_stop();
  	music_update();

	pal_bg(paletteMenu);

	vram_adr(NAMETABLE_A);
	vram_unrle(bgmtestscreen);

	song = 0;
	temptemp6 = 0; 	
	#define sfx tmp4
	sfx = 0;
	settingvalue = 0;
	menuMusicCurrentlyPlaying=0;

	ppu_on_all();
	
	pal_fade_in();
	
	while (1) {
		
		ppu_wait_nmi();
		oam_clear();
		crossPRGBankJump0(check_if_music_stopped);
		mouse_and_cursor();
		 // read the first controller
		kandoframecnt++;
		if (kandoframecnt & 1 && mouse_timer) mouse_timer--;	
		if (mouse.left_press) {
			if ((mouse.x >= 0x63 && mouse.x <= 0x8C)) {
				if (mouse.y >= 0x34 && mouse.y <= 0x3A) {		
					settingvalue = 0;
				}
				else if ((mouse.y >= 0x6C && mouse.y <= 0x73)) {		
					settingvalue = 1;
				}
			}
			if ((mouse.x >= 0x2E && mouse.x <= 0xCC)) {
				if ((mouse.y >= 0xB4 && mouse.y <= 0xBB)) {		
					if (settingvalue == 1) { sfx_play(sfx, 0); }
					else {
						if (!temptemp6) { music_play(xbgmlookuptable[song]); temptemp6 = 1; songplaying = 1; }
						else { famistudio_music_stop(); music_update(); temptemp6 = 0; songplaying = 0; }
					}
				}
				if ((mouse.y >= 0xA4 && mouse.y <= 0xAB)) {
					menu_music = song; sfx_play(sfx_orbs, 0);
				}
			}
			if ((mouse.x >= 0x56 && mouse.x <= 0xA5) && (mouse.y >= 0x24 && mouse.y <= 0x2B)) {		
				code_checker();
				if (gameState == STATE_FUNSETTINGS) return;
			}
			if ((mouse.y >= 0x4E && mouse.y <= 0x5C)) {
				if ((mouse.x >= 0x24 && mouse.x <= 0x2C)) {		
					if (song == 0) {song = song_max - 1;} else song--; temptemp6 = 0; settingvalue = 0;
				}
				else if ((mouse.x >= 0xCC && mouse.x <= 0xD4)) {		
					temptemp6 = 0; song++; if (song == song_max) {song = 0;} settingvalue = 0;
				}
			}
			if ((mouse.y >= 0x86 && mouse.y <= 0x93)) {

				if ((mouse.x >= 0x24 && mouse.x <= 0x2C)) {		
					if (sfx == 0) {sfx = sfx_max - 1;} else sfx--; settingvalue = 1;
				}
				else if ((mouse.x >= 0xCC && mouse.x <= 0xD4)) {		
					sfx++; if (sfx == sfx_max) {sfx= 0;} settingvalue = 1;
				}
			}
			if ((mouse.x >= 0x35 && mouse.x <= 0xC4)) {
				if (mouse.y >= 0xC4 && mouse.y <= 0xCD) {		
					tmp3--;			
					one_vram_buffer(' ', NTADR_A(11, 7));
					one_vram_buffer(' ', NTADR_A(11, 14));
					menuMusicCurrentlyPlaying = 1;
					gameState = STATE_MENU;
					return;
				}
				else if (mouse.y >= 0x3D && mouse.y <= 0x64) {
					if (!temptemp6) { music_play(xbgmlookuptable[song]); temptemp6 = 1; songplaying = 1; }
					else { famistudio_music_stop(); music_update(); temptemp6 = 0; songplaying = 0; }
				}
				else if (mouse.y >= 0x75 && mouse.y <= 0x9C) {
					sfx_play(sfx, 0);
				}
			}
		}			
	__A__ = idx16_load_hi_NOC(xbgmtextsUpper, song);
	if (__A__) draw_padded_text(xbgmtextsUpper[song], xbgmtextsUpperSize[song], 18, NTADR_A(7, 8));
	else one_vram_buffer_horz_repeat('$', 17, NTADR_A(7, 8));
	__A__ = idx16_load_hi_NOC(xbgmtextsLower, song);
	if (__A__) draw_padded_text(xbgmtextsLower[song], xbgmtextsLowerSize[song], 18, NTADR_A(7, 9));
	else one_vram_buffer_horz_repeat('$', 17, NTADR_A(7, 9));
	__A__ = idx16_load_hi_NOC(xbgmtextsOriginalArtist, song);
	if (__A__) draw_padded_text(xbgmtextsOriginalArtist[song], xbgmtextsOriginalArtistSize[song], 18, NTADR_A(7, 14));
	else one_vram_buffer_horz_repeat('$', 17, NTADR_A(7, 14));
	
	draw_padded_text(sfxtexts[sfx & 0x7F], sfxtextSizes[sfx], 18, NTADR_A(7, 19));

	
		if (settingvalue == 0) {
			one_vram_buffer('c', NTADR_A(11, 6));
			one_vram_buffer(' ', NTADR_A(11, 17));
			if (joypad1.press_right) { song++; temptemp6 = 0; if (song == song_max) {song = 0;} }
			if (joypad1.press_left) { if (song == 0) {song = song_max - 1;} else song--; temptemp6 = 0; }
			if (joypad1.press_a) {
					if (!temptemp6) { music_play(xbgmlookuptable[song]); temptemp6 = 1; songplaying = 1; }
					else { famistudio_music_stop(); music_update(); temptemp6 = 0; songplaying = 0; }
			}					
		}		
		else if (settingvalue == 1) {
			one_vram_buffer(' ', NTADR_A(11, 6));
			one_vram_buffer('c', NTADR_A(11, 17));
			if (joypad1.press_right) { sfx++; if (sfx == sfx_max) {sfx= 0;} };
			if (joypad1.press_left) { if (sfx == 0) {sfx = sfx_max - 1;} else sfx--; }
			if (joypad1.press_a) sfx_play(sfx, 0);
		}

		if (joypad1.press_down) settingvalue ^= 1;
		if (joypad1.press_up) settingvalue ^= 1;
		
		if (joypad1.press_select) { menu_music = song; sfx_play(sfx_orbs, 0); }
		if (joypad1.press_b) {
			tmp3--;			
			one_vram_buffer(' ', NTADR_A(11, 6));
			one_vram_buffer(' ', NTADR_A(11, 17));
			menuMusicCurrentlyPlaying = 1;
			gameState = STATE_MENU;
			return;
		}
		
		// sound test codes
		if (joypad1.press_start) {
			code_checker();
			if (gameState == STATE_FUNSETTINGS) return;
		}
	}
}
#define sfx tmp4
void code_checker() {
	last_gameState = gameState;
	sfx_play(sfx_achievement_get, 0);
	tmp3 = 1;

	// bgm 9 & sfx 2
	if (song == 0x9 && sfx == 0x2 && kandokidshack3 == 0) {
		kandokidshack3++;
		tmp3--;
	}
	
	else if (song == 1 && sfx == 7 && kandokidshack3 == 1) {
		all_levels_complete = 0xFC;
		gameState = STATE_FUNSETTINGS;
		tmp3--;
	}		
	else kandokidshack3 = 0;
	
/*   debug code disabled
	if (song == 0xB && sfx == 0x7) {
		multi_vram_buffer_horz(TEXT_debug_mode, sizeof(TEXT_debug_mode)-1, NTADR_A(7,26));
		options |= debugtoggle;
		tmp3--;
	}
*/

	// this is quite literally the greatest hack ever
	// since sfx doesn't update until the next frame i can just
	// overwrite the success sfx with the invalid one
	if (tmp3) sfx_play(sfx_invalid, 0);	
}

#undef sfx

//const char TEXT_debug_mode[] = "DEBUG MODE ENABLED";

const unsigned char bgmtestscreen[482]={
0x01,0x02,0x01,0x04,0xae,0x02,0x01,0x13,0xae,0x02,0x01,0x09,0xaf,0x02,0x01,0x13,
0xaf,0x02,0x01,0x06,0x06,0x07,0x04,0x01,0x17,0x06,0x07,0x02,0x01,0x03,0x08,0x09,
0x05,0x01,0x17,0x08,0x09,0x02,0x01,0x03,0x0c,0xff,0x01,0x07,0xf3,0xef,0xf5,0xee,
0xe4,0xff,0xf4,0xe5,0xf3,0xf4,0xff,0x01,0x07,0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,
0x19,0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,0x09,0xed,0xf5,0xf3,0xe9,0xe3,0xff,0x01,
0x0a,0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,0x03,0x5c,0xfe,0x01,0x0f,0x5d,0xff,0x01,
0x03,0x0d,0x02,0x01,0x03,0x0c,0xff,0xff,0x6e,0xff,0xfe,0x01,0x11,0xff,0x6f,0xff,
0xff,0x0d,0x02,0x01,0x03,0x0c,0xff,0xff,0x7e,0xff,0xfe,0x01,0x11,0xff,0x7f,0xff,
0xff,0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,0x03,0x6c,0xfe,0x01,0x0f,0x6d,0xff,0x01,
0x03,0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,0x19,0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,
0x08,0xe1,0xf2,0xf4,0xe9,0xf3,0xf4,0xff,0x01,0x0a,0x0d,0x02,0x01,0x03,0x0c,0xff,
0x01,0x03,0x5c,0xfe,0x01,0x0f,0x5d,0xff,0x01,0x03,0x0d,0x02,0x01,0x03,0x0c,0xff,
0x01,0x03,0xfe,0x01,0x11,0xff,0x01,0x03,0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,0x03,
0x6c,0xfe,0x01,0x0f,0x6d,0xff,0x01,0x03,0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,0x19,
0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,0x09,0xf3,0xef,0xf5,0xee,0xe4,0xff,0x01,0x0a,
0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,0x03,0x5c,0xfe,0x01,0x0f,0x5d,0xff,0x01,0x03,
0x0d,0x02,0x01,0x03,0x0c,0xff,0xff,0x6e,0xff,0xfe,0x01,0x11,0xff,0x6f,0xff,0xff,
0x0d,0x02,0x01,0x03,0x0c,0xff,0xff,0x7e,0xff,0xfe,0x01,0x11,0xff,0x7f,0xff,0xff,
0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,0x03,0x6c,0xfe,0x01,0x0f,0x6d,0xff,0x01,0x03,
0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,0x19,0x0d,0x02,0x01,0x03,0x0c,0xff,0xff,0xf3,
0xe5,0xec,0xe5,0xe3,0xf4,0xe0,0xf3,0xe5,0xf4,0xff,0xed,0xe5,0xee,0xf5,0xff,0xed,
0xf5,0xf3,0xe9,0xe3,0xff,0x01,0x02,0x0d,0x02,0x01,0x03,0x0c,0xff,0xff,0xf0,0xf2,
0xe5,0xf3,0xf3,0xff,0xe1,0xff,0xf4,0xef,0xff,0xf0,0xec,0xe1,0xf9,0xff,0xe0,0xff,
0xf3,0xf4,0xef,0xf0,0xff,0xff,0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,0x03,0xf0,0xf2,
0xe5,0xf3,0xf3,0xff,0xe2,0xff,0xf4,0xef,0xff,0xf2,0xe5,0xf4,0xf5,0xf2,0xee,0xff,
0x01,0x04,0x0d,0x02,0x01,0x03,0x0a,0x0b,0x04,0x01,0x09,0x06,0x0e,0x0e,0x07,0x04,
0x01,0x09,0x0a,0x0b,0x02,0x01,0x05,0x05,0x01,0x09,0x08,0x05,0x05,0x09,0x05,0x01,
0x09,0x02,0x01,0x43,0xff,0x5c,0x5f,0x01,0x03,0x53,0xff,0x77,0x00,0x01,0x05,0xdd,
0x77,0x00,0x01,0x05,0xdd,0x77,0x00,0x01,0x05,0xdd,0x77,0x00,0x01,0x05,0xdd,0x77,
0x00,0x01,0x05,0xdd,0xf7,0x50,0x50,0xd0,0x70,0x50,0x50,0xfd,0x0f,0x01,0x06,0x0f,
0x01,0x00
};



void decrement_was_on_slope() {
	if (currplayer_was_on_slope_counter) {
		currplayer_was_on_slope_counter--;
		
		if (!currplayer_was_on_slope_counter) {
			if (gamemode == GAMEMODE_CUBE || gamemode == GAMEMODE_BALL) {
				// Set carry to 1 if slope is upside down
				__A__ = (currplayer_slope_type & SLOPE_UPSIDEDOWN) + (256 - SLOPE_UPSIDEDOWN);
				__A__ = currplayer_table_idx & ~TBLIDX_GRAV;
				__asm__ ("adc #0 \n tay");
				// Thus, gravity in the table index is replaced with SLOPE_UPSIDEDOWN
				switch (gamemode) {
					case GAMEMODE_BALL:
						switch (currplayer_slope_type) {
							case SLOPE_22DEG_UP:
							case SLOPE_22DEG_UP_UD:
								currplayer_vel_y += EXIT_SLOPE_BALL_22(get_Y);
								break;
							case SLOPE_66DEG_UP:
							case SLOPE_66DEG_UP_UD:
								currplayer_vel_y += EXIT_SLOPE_BALL_66(get_Y);
						}
						break;
					case GAMEMODE_CUBE:
						switch (currplayer_slope_type) {
							case SLOPE_22DEG_UP:
							case SLOPE_22DEG_UP_UD:
								currplayer_vel_y += EXIT_SLOPE_CUBE_22(get_Y);
								break;
						}
						break;
				}
			}
			currplayer_slope_type = 0;
		}
	} else {
		currplayer_last_slope_type = 0;
		currplayer_slope_type = 0;
	}	
}


void check_practice_point_deletion() {
	if (practicebuffer || (practice_point_count > 1 && (joypad1.press_select || (mouse.left && mouse.right_press)) && !(joypad1.hold & (PAD_UP | PAD_DOWN)))) {
				curr_practice_point--;
				practicebuffer = 0;
				if (latest_practice_point) latest_practice_point--;
				if (curr_practice_point >= practice_point_count)
					curr_practice_point = practice_point_count - 1;
	}
}

void end_level_debug() {
				END_LEVEL_TIMER = 0;
				kandokidshack4 = 0;
				oam_clear();
				gameState = STATE_LVLDONE;
				//DEBUG_MODE = 0;
				famistudio_music_stop();
}				



void set_completion_data() {
	if (!DEBUG_MODE && !kandokidshack && !kandokidshack3 && !kandokidshack4) {
		if (!practice_point_count) {
			if (!invisblocks) {
				LEVELCOMPLETE[level] = 1;
				if (coins & COIN_1) coin1_obtained[level] = 1;
				if (coins & COIN_2) coin2_obtained[level] = 1;
				if (coins & COIN_3) coin3_obtained[level] = 1;
				level_completeness_normal[level] = 100;
			}
			else {
				invisible_LEVELCOMPLETE[level] = 1;
				if (coins & COIN_1) invisible_coin1_obtained[level] = 1;
				if (coins & COIN_2) invisible_coin2_obtained[level] = 1;
				if (coins & COIN_3) invisible_coin3_obtained[level] = 1;
				invisible_level_completeness_normal[level] = 100;
			}			
		} else {
			if (!invisblocks) level_completeness_practice[level] = 100;
			else invisible_level_completeness_practice[level] = 100;
		}
	}
}

void set_lvldone_palette() {
	mmc3_set_1kb_chr_bank_0(LEVELCOMPLETEBANK);
	mmc3_set_1kb_chr_bank_1(PRACTICECOMPLETEBANK);
	mmc3_set_1kb_chr_bank_2(LEVELCOMPLETEBANK+2);
	mmc3_set_1kb_chr_bank_3(LEVELCOMPLETEBANK+3);
	mmc3_set_2kb_chr_bank_1(MOUSEBANK);

	// Set palettes back to natural colors since we aren't fading back in
	pal_bright(4);
	pal_bg(paletteMenu);
	pal_col(0x0A,0x2A);
	pal_col(0x0B,0x21);
	pal_set_update();
    //pal_spr(paletteMenu);
	pal_spr(paletteDefaultSP);
}