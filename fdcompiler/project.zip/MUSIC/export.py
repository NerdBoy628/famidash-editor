#!/usr/bin/env python3

import sys
import pathlib
import itertools
import subprocess
import re
from collections.abc import Iterable

famistudioHelpRegex = r"FamiStudio (?P<version>.+) Command-Line Usage"

instSizeRegex = "Info: Instruments size : (?P<instSize>.+) bytes\\."
songSizeRegex = "Info: Song '(?P<songName>.+)' size: (?P<songSize>.+) bytes\\."
totalSizeRegex = "Info: Total assembly file size: (?P<totalSize>.+) bytes\\."
youMustSetRegex = "Info: ([^\n]+, you must set [^\n]+\\.)"
actualOptionRegex = "set (FAMISTUDIO_[^ \n=]+ = [^ \n.]+)"

fsTxtIndentRegex = r'^(?P<indent>\t*)'
fsTxtLineRegex = r'^(?P<indent>\t*)(?P<type>\S+)\s+(?P<properties>.*)$'
fsTxtPropRegex = r'(?:(\S+)="([^"]*)"\s*)'

exportStemPrefix = "music"

dpcmFileNameRegex = f'{exportStemPrefix}_(?P<musicBank>.+)_bank(?P<dpcmBank>.+).dmc'

finalSongInListName = "max"

asmMusicDataName = fr'music_data_famidash_{exportStemPrefix}'
asmAmountOfSongsRegex = fr'({asmMusicDataName}:.*?\n\t\.byte )(\d+)'
asmDpcmSongHeaderMatchRegex = lambda dpcmAlignerName : r'(?m:^; \d+ : ' + dpcmAlignerName + r'.*?$\n(?:^\t\.word @song\d+.*?$\n){5}^\t.word \d+,\d+.*?$\n)'
asmDpcmSongHeaderIdxRegex = lambda dpcmAlignerName : r'(?m:^; \d+ : ' + dpcmAlignerName + r'.*?$\n(?:^\t\.word @song(\d+).*?$\n){5}^\t.word \d+,\d+.*?$\n)'
asmDpcmSongMatchRegex = lambda x : r'(?ms:(^@song' + x + r'\S*:.*?)(?=^@song(?!' + x + r')))' #BUG: currently doesn't match if the dpcm song is the last

datBankSegPrefix = "DAT_BANK_"
dmcBankMetaUnused = 63  # a special dmc bank for shit to go unused
musicFolder = pathlib.Path(sys.path[0]).resolve()
tmpFolder = (musicFolder.parent / "TMP").resolve()

# Because itertools is old af sometimes
def batched(iterable, n, *, strict=False):
    # batched('ABCDEFG', 3) → ABC DEF G
    if n < 1:
        raise ValueError('n must be at least one')
    iterator = iter(iterable)
    while batch := tuple(itertools.islice(iterator, n)):
        if strict and len(batch) != n:
            raise ValueError('batched(): incomplete batch')
        yield batch

def pairwise(iterable):
    iterator = iter(iterable)
    a = next(iterator, None)

    for b in iterator:
        yield a, b
        a = b


def checkErr(proc : subprocess.CompletedProcess):
    if (proc.returncode != 0):
        print(f"AN ERROR HAS OCCURED WITHIN A SUBPROCESS!\n======\nstdout dump:\n===\n{proc.stdout.decode()}\n===\nstderr dump:\n===\n{proc.stderr.decode()}\n===")
        proc.check_returncode() # exits


# Local version of FamiStudio function
# Source code @ https://github.com/BleuBleu/FamiStudio/blob/master/FamiStudio/Source/Utils/Utils.cs
# Function name: Utils.MakeNiceAsmName
# Make sure to keep this updated
def makeNiceAsmName(name : str, allowDash : bool = False) -> str:
    niceName = ""
    for c in name:
        if (c.isalnum()):
            niceName += c.lower();
        elif (c.isspace() and niceName[-1] != '_'):
            niceName += '_'
        elif (c == '-'):
            niceName += '-' if allowDash else '_'
        elif (c == '_'):
            niceName += c
    return niceName

def convertTextToMenuFormat(name : str | None) -> str | None:
    if name == None:
        return None
    niceName = ""
    for c in name:
        if (c.isalpha()) or (c.isdigit()):
            niceName += c
        elif (c.isspace()):
            niceName += "$"
        else:
            print(f"Warning: illegal character '{c}' detected in sound test string '{name}'. Will be omitted.")
    return niceName

def processNSFTrackAuthorMetadata(author : str | dict) -> str:
    if isinstance(author, str):
        return author
    if author == None:
        print(f"Warning: NSF author metadata not specified")
        return "[NOT SPECIFIED]"
    if not isinstance(author, dict):
        print(f"Warning: NSF author metadata '{author}' is neither a string nor a dictionary")
        return "[ERROR]"
    if 'original' in author.keys() and 'cover' in author.keys():
        return f"Original by {author['original']}, covered by {author['cover']}"
    print(f"Warning: Invalid NSF author metadata structure '{author}'")
    return "[ERROR]"

def processMetadata(metadata : dict) -> dict:
    songlist = [i for i in metadata['songs'] if 'fmsSongName' in i.keys()] # filter out commented out songs

    # Get song names
    songNameList = ['song_' + makeNiceAsmName(i.get('fmsSongName'), False) for i in songlist]
    vsSongNameList = ['song_' + makeNiceAsmName(i.get('fmsSongName'), False) for i in songlist if i.get('vsSystemEnabled') == True]

    # Extended metadata or not?
    extMeta = metadata.get('extendedMetadata', False)

    # Optimize text usage
    if not extMeta:
        # Main system
        textKeyList = ['upperText', 'lowerText', 'originalArtistText']
    else:
        # The album
        # First, generate the artist entries
        artistMappingTable = metadata.get('artistTextMappingTable', {})
        artistMetadataKeys = {
            'original': [f'{i}OrigArtistText' for i in ['upper', 'lower']],
            'covering': [f'coveringArtist{i}Text' for i in range(1, 4+1)]
        }
        for entry in songlist:
            for artistType in ['original', 'covering']:
                artistData = entry.get(f'{artistType}Artist', [])
                if not isinstance(artistData, list):
                    artistData = [artistData]
                for key, artist in zip(artistMetadataKeys[artistType], artistData):
                    # Cut off if too many artists; possibly make a better system for more artists later
                    if key not in entry.keys(): # If the text already exists, do not replace
                        entry[key] = (
                            artist.upper() if artist not in artistMappingTable
                            else artistMappingTable[artist]
                        )
        # Finally, the corresponding metadata keys
        textKeyList = [
            'upperText', 'lowerText',
            *artistMetadataKeys['original'],
            *artistMetadataKeys['covering']
        ]

        # TODO eventually: generate NSF metadata from this



    totalTextList = []
    textLists = {}
    for key in textKeyList:
        # Get text
        textLists[key] = [i.get(key) for i in songlist]
        totalTextList += [i for i in textLists[key] if i]
    totalTextSet = tuple(sorted(set(totalTextList), key=lambda x : totalTextList.index(x)))
    idxLists = {key: 
            [totalTextSet.index(i) if i else None for i in textLists[key]]
        for key in textKeyList}

    # Convert to displayable format
    processedTextList = tuple(map(convertTextToMenuFormat, totalTextSet))

    # Convert to C
    outputStringsList = [f'const char musicSoundTestString{i:02X}[{len(s):2}] = "{s}";' for i, s in enumerate(processedTextList)]

    pointerArrays = {key: 
            [f'\tmusicSoundTestString{i:02X},' if i != None else '\tNULL,' for i in idxLists[key]]
        for key in textKeyList}

    sizeArrays = {key: 
            [f'\tsizeof(musicSoundTestString{i:02X}),' if i != None else '\t0,' for i in idxLists[key]]
        for key in textKeyList}

    # Get SFX names
    sfxTextList = [i['text'] for i in metadata['SFX'] if 'text' in i.keys() and i['text']]
    sfxTextSet = tuple(sorted(set(sfxTextList), key=lambda x : sfxTextList.index(x)))
    sfxIdxList = [sfxTextSet.index(i) for i in sfxTextList]
    processedSfxTextList = tuple(map(convertTextToMenuFormat, sfxTextSet))

    # Convert to C
    sfxOutputStringsList = [f'const char sfxSoundTestString{i:02X}[{len(s):2}] = "{s}";' for i, s in enumerate(processedSfxTextList)]
    sfxArrayList = [f'\tsfxSoundTestString{i:02X},' if i != None else '\tNULL,' for i in sfxIdxList]
    sfxSizeArrayList = [f'\tsizeof(sfxSoundTestString{i:02X}),' if i != None else '\t0,' for i in sfxIdxList]

    # Get PCM data
    pcmlist = [i for i in metadata['PCM'] if set(['segment', 'path', 'sampleRateNTSC', 'sampleRatePAL']).issubset(set(i.keys()))]
    bankIncludesList = [f"\t.byte <.bank(pcmData{i})" for i in range(len(pcmlist))]
    sampleRateNTSCList = [f"\t.byte {i['sampleRateNTSC']}" for i in pcmlist]
    sampleRatePALList = [f"\t.byte {i['sampleRatePAL']}" for i in pcmlist]
    pcmHeaderList = ['', '; PCM includes']
    for idx, i in enumerate(pcmlist):
        pcmHeaderList += [f'.segment "{i["segment"]}"', f'\tpcmData{idx}:', f'\t\t.incbin "{i["path"]}"']

    # Get NSF metadata
    nsfMetaList = [i.get('nsfData') for i in (songlist + metadata['SFX'] + metadata['PCM']) if 'nsfData' in i.keys()]
    # For now, don't warn people of missing NSF metadata, but do warn about incomplete data
    trackLabelList = [i.get('trackLabel') for i in nsfMetaList]
    trackAuthorList = [processNSFTrackAuthorMetadata(i.get('trackAuthor')) for i in nsfMetaList]
    loopList = [i.get('looped') == True for i in nsfMetaList] # do not warn, assume false if not present
    defTime = -1 & 0xFFFFFFFF # default time
    durationFadeList = [defTime if i else 0 for i in loopList] # either 0 for None, or -1 for default
    durationNTSCList = [i['durationNTSC'] * (2 if loopList[idx] else 1) if 'durationNTSC' in i.keys() else defTime for idx, i in enumerate(nsfMetaList)]
    durationPALList = [i['durationPAL'] * (2 if loopList[idx] else 1) if 'durationPAL' in i.keys() else defTime  for idx, i in enumerate(nsfMetaList)]

    return {
        'filteredSongList': songlist,
        'soundTestData': {
            'songNames': songNameList,
            'vsSongNames': vsSongNameList,
            
            'musicSoundTestStrings': outputStringsList,
            'musicPtrs': pointerArrays,
            'musicSizes': sizeArrays,

            'sfxSoundTestStrings': sfxOutputStringsList,
            'sfxPtrs': sfxArrayList,
            'sfxSizes': sfxSizeArrayList,
        },
        'nsfMetadata': {
            'trackLabelList': trackLabelList,
            'trackAuthorList': trackAuthorList,

            'durationNTSCList': durationNTSCList,
            'durationPALList': durationPALList,
            'durationFadeList': durationFadeList
        },
        'pcmMetadata': {
            'bankTable': bankIncludesList,
            'sampleRateNTSC': sampleRateNTSCList,
            'sampleRatePAL': sampleRatePALList,
            'headerData': pcmHeaderList
        },
        'dpcmAlignerName': metadata['dpcmAligner'],
        'songModule': metadata['songModule'],
        'extendedMetadata': extMeta
    }

def parseFSTextFile(file : pathlib.Path | list[str], indent = 0, indentArr = None):
    output = []
    if isinstance(file, pathlib.Path):
        filedata = list(file.open())
    else:
        filedata = file.copy()
    if not indentArr:
        indentArr = [len(re.match(fsTxtIndentRegex, line)['indent']) for line in filedata]
    indentIdxs = [idx for idx, ind in enumerate(indentArr) if ind == indent]
    indentIdxs.append(len(indentArr))
    for lineStart, lineEnd in pairwise(indentIdxs):
        data = re.match(fsTxtLineRegex, filedata[lineStart]).groupdict()

        linetype = data['type']
        properties = re.findall(fsTxtPropRegex, data['properties'])
        lineobj = {"__type": linetype, **dict(properties)}
        
        if lineStart < lineEnd - 1:
            # Recursion
            lineobj['__subordinates'] = parseFSTextFile(filedata[lineStart+1:lineEnd], indent+1, indentArr[lineStart+1:lineEnd])
        output.append(lineobj)
    return output
        
def tidyUpFSTextData(data : list, uppermostLevel = True):
    objtypes = set()
    for obj in data:
        objtypes.add(obj['__type'])
        if '__subordinates' in obj.keys():
            # Recurse to tidy up shit
            subordinates = tidyUpFSTextData(obj['__subordinates'], False)
            # Get types of subordinates
            subtypes = {i['__type'] for i in subordinates}
            subtypes = {i : [] for i in subtypes}
            # Remove old subordinates
            obj.pop('__subordinates')
            obj.update(subtypes)
            # Sort subordinates per category
            for i in subordinates:
                type = i.pop('__type')
                obj[type].append(i)
    if not uppermostLevel:
        return data
    else:
        return {objtype : [obj for obj in data if obj.pop('__type') == objtype] for objtype in objtypes}

def exportMusicBank(bin_, fsCmd, modulePath, exportPath, dpcmidx, dpcmAlignerName, bank : int):
        idxs, names, _ = zip(*sorted(bin_))
        idxs = ','.join(map(str, idxs))
        names = list(map(makeNiceAsmName, names))

        asmExportStem = f"{exportStemPrefix}_{bank}"
        asmExportPath = exportPath / f"{asmExportStem}.s"

        proc = subprocess.run([*fsCmd, modulePath, 'famistudio-asm-export', asmExportPath, '-famistudio-asm-format:ca65', f'-export-songs:{dpcmidx},{idxs}', 'famistudio-asm-dpcm-export-mode:minimum'], capture_output=True)
        output = proc.stdout.decode()
        checkErr(proc)

        print(f"== Info on bank {bank}:")
        print("\t" + re.search(totalSizeRegex, output).group())

        # Run the asm file through a few regexes:
        captData = []
        asmExportData = asmExportPath.read_text()
        for capt, og, repl in [
            # Decrement song count
            (None, asmAmountOfSongsRegex, lambda x : f'{x.group(1)}{int(x.group(2)) - 1}'),
            # Make the label unique
            (None, asmMusicDataName, f"{asmMusicDataName}{bank}"),
            # Remove DPCM aligner from header
            (asmDpcmSongHeaderIdxRegex(dpcmAlignerName), asmDpcmSongHeaderMatchRegex(dpcmAlignerName), "; The DPCM aligner used to be here\n"),
            # Remove DPCM aligner song data
            (None, lambda : asmDpcmSongMatchRegex(captData[2][0]), "; The DPCM aligner used to be here\n")
        ]:
            if capt != None:
                captData.append(re.findall(capt, asmExportData))
            else:
                captData.append(None)

            if callable(og):
                asmExportData = re.sub(og(), repl, asmExportData)
            else:
                asmExportData = re.sub(og, repl, asmExportData)
        asmExportPath.write_text(asmExportData)

        return [
            list(exportPath.glob(f"{asmExportStem}*.dmc")),   # 0: dpcmFiles
            list(re.findall(youMustSetRegex, output)),        # 1: optionsToSet
            list(names)                                       # 2: masterSonglist
        ]

if __name__ == "__main__":
    # install binpacking and pyjson5
    install_list = []

    import importlib.util
    spec = importlib.util.find_spec('binpacking')
    if spec is None:
        install_list.append('binpacking')

    spec = importlib.util.find_spec('pyjson5')
    if spec is None:
        install_list.append('pyjson5')

    if len(install_list):
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', *install_list])

    import os, filecmp
    import argparse
    import binpacking
    import pyjson5
    import time
    import multiprocessing
    
    parser = argparse.ArgumentParser()
    parser.add_argument('-f', '--famistudioCommand', required=True, nargs="+",
                help='Command to launch FamiStudio >= 4.4.2')
    parser.add_argument('-m', '--metadata', type=pathlib.Path, required=True,
                help='Path to json5 file with music metadata specifications')
    parser.add_argument('-o', '--outputFolder', type=pathlib.Path, required=True,
                help='Output folder for the include files')
    args = parser.parse_args()
    
    
    metadataPath = args.metadata

    fsCmd = args.famistudioCommand

    # Load metadata file
    print("\n==== Loading metadata...")
    if not(metadataPath.is_file()):
        print("Path to the metadata json5 file is invalid. Please specify a proper file.")
        exit(1)
    with metadataPath.open() as metafile:
        metadata = pyjson5.decode_io(metafile)
    
    # Process metadata
    print("\n==== Processing metadata...")
    processed_metadata = processMetadata(metadata)

    modulePath = musicFolder / "MODULES" / processed_metadata['songModule']
    extMeta = processed_metadata['extendedMetadata']
    
    # Check FamiStudio version
    print("\n==== Checking FamiStudio version...")
    proc = subprocess.run([*fsCmd, '-help'], capture_output=True)
    checkErr(proc)
    fsVer = re.search(famistudioHelpRegex, proc.stdout.decode())['version']
    fsVer = [int(x) for x in fsVer.split(".")]
    fsVer = fsVer[0]*1000_000 + fsVer[1]*1000 + fsVer[2]
    if (fsVer < 400_400_2):
        print("FamiStudio is older than 4.4.2, please upgrade to version 4.4.2.")
        exit(1)

    # Get FamiStudio text file
    print("\n==== Exporting a FamiStudio text file for processing...")
    fsTxtPath = tmpFolder / "{exportStemPrefix}_fs.txt"

    proc = subprocess.run([*fsCmd, modulePath, 'famistudio-txt-export', fsTxtPath], capture_output=True)
    checkErr(proc)
    if fsTxtPath.is_file():
        fsTxtData = parseFSTextFile(fsTxtPath)
        fsTxtData = tidyUpFSTextData(fsTxtData)
        # Assume there's only one project that got exported
        fsTxtData = fsTxtData['Project'][0]
        fsTxtPath.unlink(missing_ok = True)
    else:
        print("Somehow the famistudio-txt-export process didn't create a valid text file.")
        exit(2)
    
    dpcmAlignerName = processed_metadata['dpcmAlignerName']

    songNames = [song['Name'] for song in fsTxtData['Song']]
    if dpcmAlignerName == "dpcm_BIG":
    # special case if aligner is dpcm_BIG
        lastDatBank = 0x73    
    elif dpcmAlignerName == "dpcm_HUGE":
    # special case if aligner is dpcm_BIG
        lastDatBank = 0xEF
    elif dpcmAlignerName == "dpcm_ALBUM":
        lastDatBank = 0x3B
    else:
        lastDatBank = 0x33
    
    neededSongNames = sorted(i['fmsSongName'] for i in processed_metadata['filteredSongList'])
    if any(i not in songNames for i in neededSongNames):
        print('Songs ', ", ".join([f'"{i}"' for i in neededSongNames if i not in songNames]), ' not found in FamiStudio module. Please check the song names', sep="")
        exit(2)
    neededSongs = [songNames.index(i) for i in neededSongNames]

    if len(songNames) == 0:
        print("No valid songs found in FS txt file.")
        exit(2)
    
    if not(dpcmAlignerName in songNames):
        print("DPCM aligner not found in FS txt file.")
        exit(2)

    dpcmidx = songNames.index(dpcmAlignerName)
    neededSongsCommaSep = ",".join([str(i) for i in neededSongs])

    # Get instrument and song sizes
    print("\n==== Getting sizes of songs and instruments...")
    tmpAsmPath = tmpFolder / f"{exportStemPrefix}_all.s"

    proc = subprocess.run([*fsCmd, modulePath, 'famistudio-asm-export', tmpAsmPath, '-famistudio-asm-format:ca65', '-famistudio-asm-force-dpcm-bankswitch', f'-export-songs:{neededSongsCommaSep},{dpcmidx}'], capture_output=True)
    tmpAsmPath.unlink(missing_ok = True)
    checkErr(proc)

    for i in tmpFolder.glob(f"{exportStemPrefix}_all*.dmc"):
        i.unlink(missing_ok = True)
    
    cmdOutput = proc.stdout.decode()
    
    # Get size of all instruments
    instsize = re.search(instSizeRegex, cmdOutput)
    if (not instsize):
        print("Instrument size not correctly present in the FamiStudio command output.")
        exit(3)
    instsize = int(instsize['instSize'])
    if extMeta:
        maxDataInBank = 8192 - (instsize / 8 * 3)
    elif dpcmAlignerName == "dpcm_E-sides":
        maxDataInBank = 8192 - (instsize / 3 * 3)
    else:
        maxDataInBank = 8192 - (instsize / 5 * 3)
    print(f"== Total maximum size of data in a bank is {maxDataInBank} bytes")

    # Get song sizes in bytes
    songsizestrings = re.finditer(songSizeRegex, cmdOutput)
    songsizes = [[
            songNames.index(match['songName']),
            match['songName'],
            int(match['songSize'])
        ] for match in songsizestrings if match['songName'] != dpcmAlignerName]
    SONG_IDX_IDX = 0
    SONG_NAME_IDX = 1
    SONG_SIZE_IDX = 2
    bins = binpacking.to_constant_volume(songsizes, maxDataInBank, 2)
    for idx, bank in enumerate(bins):
        print(f"== Bank {idx}:")
        print("\t- Songs: "+", ".join([j[SONG_NAME_IDX] for j in bank]))
        print("\t- Total approx. size:", sum([j[SONG_SIZE_IDX] for j in bank]), "bytes")

    # Export the music_X.s files
    exportPath = args.outputFolder
    if not exportPath.is_dir():
        exportPath.mkdir(parents=True)

    print("\n==== Running export processes of each music data bank...")

    timeStart = time.time_ns()

    with multiprocessing.Pool() as pool:
        dpcmFiles, optionsToSet, masterSonglist = zip(*pool.starmap(exportMusicBank, 
            [[bins[bank], fsCmd, modulePath, exportPath, dpcmidx, dpcmAlignerName, bank] for bank in range(len(bins))]))

    # Flatten lists
    dpcmFiles = list(itertools.chain.from_iterable(dpcmFiles))
    optionsToSet = list(itertools.chain.from_iterable(optionsToSet))
    masterSonglist = list(itertools.chain.from_iterable(masterSonglist))

    masterSonglist.append(finalSongInListName)

    print(f"\n== Export took {round((time.time_ns() - timeStart) / 1000000000, ndigits=4)} seconds")

    # Check the DPCM files for being identical
    print("\n==== Checking if the DPCM files are identical...")
    
    dpcmFiles = [{
        "path": i,
        **re.search(dpcmFileNameRegex, i.name).groupdict()
    } for i in dpcmFiles]
    dpcmError = False
    dpcmBanks = list(set([i['dpcmBank'] for i in dpcmFiles]))
    for bank in dpcmBanks:
        bankDpcmError = False
        dpcmFilesOfBank = [file for file in dpcmFiles if file['dpcmBank'] == bank]
        for file in dpcmFilesOfBank:
            if not(filecmp.cmp(file['path'], dpcmFilesOfBank[0]['path'], shallow=False)):
                print(f"DPCM Data Bank {file['dpcmBank']} of music data bank {file['musicBank']} differs from that of music data bank 0.")
                bankDpcmError = True
                dpcmError = True
        if not bankDpcmError:
            (exportPath / f"{exportStemPrefix}_bank{bank}.dmc").unlink(missing_ok = True)
            dpcmFilesOfBank[0]['path'].rename(exportPath / f"{exportStemPrefix}_bank{bank}.dmc")
            dpcmFilesOfBank.pop(0)
        [i['path'].unlink(missing_ok = True) for i in dpcmFilesOfBank]

    if dpcmError:
        ValueError("DPCM files were not identical. Please check the dpcm aligner for containing all samples.")
        exit(4)    

    dpcmBanks = sorted(list(map(int, dpcmBanks)))
    
    print("\n==== Exporting miscellaneous files...")
    print("== musicPlayRoutines.s")
    # Export bank lengths table
    bank_table_data = [
        '; Generated by export.py',
        '',
        ".if .not(useConstInitPtr)",
        "music_data_locations_lo:",
        f"\t.byte " + ", ".join([f"<{asmMusicDataName}{i}" for i in range(len(bins))]),
        "music_data_locations_hi:",
        f"\t.byte " + ", ".join([f">{asmMusicDataName}{i}" for i in range(len(bins))]),
        ".endif",
        "",
        "music_counts:",
        f"\t.byte {', '.join([str(len(i)) for i in bins[:-1]])}, $FF ;last bank is marked with an FF to always stop bank picking"
        ]
    (exportPath / "musicPlayRoutines.s").write_text("\n".join(bank_table_data))

    # Export C songlist
    print("== musicDefines.h")
    (exportPath / "musicDefines.h").write_text(
        "\n".join([f"#define song_{id} {i}" for i, id in enumerate(masterSonglist)]))

    # Export asm songlist
    print("== music_songlist.inc")
    (exportPath / "music_songlist.inc").write_text(
        "\n".join([f"song_{id} = {i}" for i, id in enumerate(masterSonglist)]))

    # Export segment assignment
    print("== music_data_header.s")
    lastAfterDatBank = lastDatBank + 1
    firstDmcBank = lastAfterDatBank - len([i for i in dpcmBanks if i != dmcBankMetaUnused])
    firstMusBank = firstDmcBank - len(bins)

    header_music_bank_data = []
    for i in range(1, len(bins)):   # The first music bank is special
        header_music_bank_data += [
            f'.segment "{datBankSegPrefix}{i+firstMusBank:02X}"',
            f'\t.include "{exportStemPrefix}_{i}.s"'
        ]

    if (len(dpcmBanks)):
        header_dmc_bank_data = [
            '', '; DMC banks',
            f'.segment "{datBankSegPrefix}{firstDmcBank:02X}"',
            '\tfirstDMCBankPtr := *',
            f'\t.incbin "{exportStemPrefix}_bank{dpcmBanks[0]}.dmc"',
        ]
        for i, bank in enumerate(dpcmBanks[1:], 1):
            if bank != dmcBankMetaUnused:
                header_dmc_bank_data += [
                    f'.segment "{datBankSegPrefix}{i+firstDmcBank:02X}"',
                    f'\t.incbin "{exportStemPrefix}_bank{bank}.dmc"'
                ]
        header_dmc_bank_constant = ['FIRST_DMC_BANK = .bank(firstDMCBankPtr)']
    else:
        header_dmc_bank_data = []
        header_dmc_bank_constant = []

    header_data = [
        '; Generated by export.py using data in metadata.json',
        '', '; Music data banks',
        f'.segment "{datBankSegPrefix}{firstMusBank:02X}"',
        '\tfirstMusicBankPtr := *',
        f'\t.include "{exportStemPrefix}_0.s"',
        *header_music_bank_data,
        *header_dmc_bank_data,
        *processed_metadata['pcmMetadata']['headerData'],
        '', '; Constants',
        'FIRST_MUSIC_BANK = .bank(firstMusicBankPtr)',
        *header_dmc_bank_constant,
        ''
    ]

    (exportPath / "music_data_header.s").write_text("\n".join(header_data))

    print(f"== {exportStemPrefix}_soundTestTables.h")
    processed_soundtest_metadata = processed_metadata['soundTestData']

    mainArrays = []
    vsArrays = []

    for key in processed_soundtest_metadata['musicPtrs'].keys():
        arrName = key[0].upper() + key[1:-4] # remove the Text at the end
        mainArrays += [
            '', f'const char* const xbgmtexts{arrName}[] = {{',
            *processed_soundtest_metadata['musicPtrs'][key],
            '};',
            '', f'const uint8_t xbgmtexts{arrName}Size[] = {{',
            *processed_soundtest_metadata['musicSizes'][key],
            '};',
            ''
        ]
        vsArrays += [
            f'const char* const xbgmtexts{arrName}[] = {{}};',
            f'const uint8_t xbgmtexts{arrName}Size[] = {{}};',
        ]

    soundTestTextData = [
        '// Generated by export.py using data in metadata.json',
        '', '#if !__VS_SYSTEM',
        '', *processed_soundtest_metadata['musicSoundTestStrings'],
        '', *mainArrays,
        '', '#else',
        '', *vsArrays,
        '', '#endif',
        '', '', '',
        'CODE_BANK_PUSH("RODATA")',
        '', '#if !__VS_SYSTEM',
        '', 'const uint8_t xbgmlookuptable[] = {',
        *[f"\t{i}," for i in processed_soundtest_metadata['songNames']],
        '};',
        '', '#else',
        '', 'const uint8_t xbgmlookuptable[] = {',
        *[f"\t{i}," for i in processed_soundtest_metadata['vsSongNames']],
        '};',
        '', '#endif',
        '', 'CODE_BANK_POP()',
        ''
    ]
    (exportPath / f"{exportStemPrefix}_soundTestTables.h").write_text("\n".join(soundTestTextData))

    print(f"== sfx_soundTestTables.h")
    soundTestSfxTextData = [
        '// Generated by export.py using data in metadata.json',
        '', '#if !__VS_SYSTEM',
        '', *processed_soundtest_metadata['sfxSoundTestStrings'],
        '',
        '', 'const char* const sfxtexts[] = {',
        *processed_soundtest_metadata['sfxPtrs'],
        '};',
        '', 'const uint8_t sfxtextSizes[] = {',
        *processed_soundtest_metadata['sfxSizes'],
        '};',
        '', '#else',
        '',
        'const char* const sfxtexts[] = {};',
        'const uint8_t sfxtextSizes[] = {};',
        '',
        '#endif',
        ''
    ]
    (exportPath / "sfx_soundTestTables.h").write_text("\n".join(soundTestSfxTextData))

    print("== pcm_metadataTables.s")
    pcmMetadataText = [
        '; Generated by export.py using data in metadata.json',
        '', 'Bank:',
        *processed_metadata['pcmMetadata']['bankTable'],
        '', 'SampleRate_NTSC:   ; Also applies to Dendy, as it is derived from the CPU speed',
        *processed_metadata['pcmMetadata']['sampleRateNTSC'],
        '', 'SampleRate_PAL:',
        *processed_metadata['pcmMetadata']['sampleRatePAL'],
        ''
    ]
    (exportPath / "pcm_metadata.s").write_text("\n".join(pcmMetadataText))

    print("== nsf_metadata.s")
    processed_nsf_metadata = processed_metadata['nsfMetadata']
    nsfMetadataText = [
        '; Generated by export.py using data in metadata.json',
        '',
        'RIFFChunkStart "tlbl"',
        *[f'.asciiz "{i}"' for i in processed_nsf_metadata['trackLabelList']],
        '',
        'RIFFChunkStart "taut"',
        *[f'.asciiz "{i}"' for i in processed_nsf_metadata['trackAuthorList']],
        '',
        'RIFFChunkStart "time"',
        '.if REGION = 0',
        *['.dword ' + ", ".join(i) for i in batched(map(str, processed_nsf_metadata['durationNTSCList']), 4)],
        '.else',
        *['.dword ' + ", ".join(i) for i in batched(map(str, processed_nsf_metadata['durationPALList']), 4)],
        '.endif',
        '',
        'RIFFChunkStart "fade"',
        *['.dword ' + ", ".join(i) for i in batched(map(str, processed_nsf_metadata['durationFadeList']), 4)],
        ''
    ]
    (exportPath / "nsf_metadata.s").write_text("\n".join(nsfMetadataText))

    # Print which options to set
    print("\n==== Don't forget to set these options in the sound driver:")
    print("\n".join(re.findall(actualOptionRegex, "\n".join(list(set(optionsToSet))))))

    print("\n==== The export is over, now manually correct stuff as per the contributing guide")
