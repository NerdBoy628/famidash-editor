void mouse_and_cursor();
void lvl_done_update();
void refresh_queue_screen();
void play_next_queue();
void text_stuff();
void update_text1();
void update_text2();
void update_text3();



CODE_BANK_PUSH("XCD_BANK_10")

const unsigned char state_soundtestscreen[468]={
0x01,0x02,0x01,0x04,0xae,0x02,0x01,0x13,0xae,0x02,0x01,0x09,0xaf,0x02,0x01,0x13,
0xaf,0x02,0x01,0x06,0x06,0x07,0x04,0x01,0x17,0x06,0x07,0x02,0x01,0x03,0x08,0x09,
0x05,0x01,0x17,0x08,0x09,0x02,0x01,0x03,0x0c,0xff,0x01,0x19,0x0d,0x02,0x01,0x03,
0x0c,0xff,0x01,0x09,0xed,0xf5,0xf3,0xe9,0xe3,0xff,0x01,0x0a,0x0d,0x02,0x01,0x03,
0x0c,0xff,0x01,0x02,0x5c,0xfe,0x01,0x11,0x5d,0xff,0x01,0x02,0x0d,0x02,0x01,0x03,
0x0c,0xff,0x6e,0xff,0xfe,0x01,0x13,0xff,0x6f,0xff,0x0d,0x02,0x01,0x03,0x0c,0xff,
0x7e,0xff,0xfe,0x01,0x13,0xff,0x7f,0xff,0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,0x02,
0x6c,0xfe,0x01,0x11,0x6d,0xff,0x01,0x02,0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,0x19,
0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,0x04,0xef,0xf2,0xe9,0xe7,0xe9,0xee,0xe1,0xec,
0xff,0xe1,0xf2,0xf4,0xe9,0xf3,0xf4,0xff,0x01,0x05,0x0d,0x02,0x01,0x03,0x0c,0xff,
0x5c,0xfe,0x01,0x15,0x5d,0xff,0x0d,0x02,0x01,0x03,0x0c,0xff,0xfe,0x01,0x17,0xff,
0x0d,0x02,0x01,0x03,0x0c,0xff,0xfe,0x01,0x17,0xff,0x0d,0x02,0x01,0x03,0x0c,0xff,
0x6c,0xfe,0x01,0x15,0x6d,0xff,0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,0x19,0x0d,0x02,
0x01,0x03,0x0c,0xff,0x01,0x06,0xe3,0xef,0xf6,0xe5,0xf2,0xe5,0xe4,0xff,0xe2,0xf9,
0xff,0x01,0x08,0x0d,0x02,0x01,0x03,0x0c,0xff,0x5c,0xfe,0x01,0x15,0x5d,0xff,0x0d,
0x02,0x01,0x03,0x0c,0xff,0xfe,0x01,0x17,0xff,0x0d,0x02,0x01,0x03,0x0c,0xff,0xfe,
0x01,0x17,0xff,0x0d,0x02,0x01,0x03,0x0c,0xff,0xfe,0x01,0x17,0xff,0x0d,0x02,0x01,
0x03,0x0c,0xff,0xfe,0x01,0x17,0xff,0x0d,0x02,0x01,0x03,0x0c,0xff,0x6c,0xfe,0x01,
0x15,0x6d,0xff,0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,0x19,0x0d,0x02,0x01,0x03,0x0c,
0xff,0xff,0xf3,0xe5,0xec,0xe5,0xe3,0xf4,0xe0,0xff,0xf4,0xef,0xe7,0xe7,0xec,0xe5,
0xff,0xf0,0xec,0xe1,0xf9,0xec,0xe9,0xf3,0xf4,0xff,0x0d,0x02,0x01,0x03,0x0c,0xff,
0xff,0xf0,0xf2,0xe5,0xf3,0xf3,0xff,0xe1,0xff,0xf4,0xef,0xff,0xf0,0xec,0xe1,0xf9,
0xff,0xe0,0xff,0xf3,0xf4,0xef,0xf0,0xff,0xff,0x0d,0x02,0x01,0x03,0x0c,0xff,0x01,
0x03,0xf0,0xf2,0xe5,0xf3,0xf3,0xff,0xe2,0xff,0xf4,0xef,0xff,0xe5,0xf8,0xe9,0xf4,
0xff,0x01,0x06,0x0d,0x02,0x01,0x03,0x0a,0x0b,0x04,0x01,0x09,0x06,0x0e,0x0e,0x07,
0x04,0x01,0x09,0x0a,0x0b,0x02,0x01,0x05,0x05,0x01,0x09,0x08,0x05,0x05,0x09,0x05,
0x01,0x09,0x02,0x01,0x03,0xff,0x5c,0x5f,0x01,0x03,0x53,0xff,0x77,0x00,0x01,0x05,
0xdd,0x77,0x00,0x01,0x05,0xdd,0x77,0x00,0x01,0x05,0xdd,0x77,0x00,0x01,0x05,0xdd,
0x77,0x00,0x01,0x05,0xdd,0x77,0x00,0x01,0x05,0xdd,0x0f,0x05,0x05,0x0d,0x07,0x05,
0x05,0x0f,0x01,0x00
};



const unsigned char SoundQueue[416]={
0x01,0x02,0x01,0x04,0xae,0x02,0x01,0x13,0xae,0x02,0x01,0x09,0xaf,0x02,0x01,0x13,
0xaf,0x02,0x01,0x04,0x06,0x07,0x04,0x01,0x1b,0x06,0x07,0x08,0x09,0x05,0x01,0x1b,
0x08,0x09,0x0c,0xff,0x01,0x1d,0x0d,0x0c,0xff,0x01,0x0b,0xed,0xf5,0xf3,0xe9,0xe3,
0xff,0x01,0x0c,0x0d,0x0c,0xff,0x01,0x04,0x5c,0xfe,0x01,0x11,0x5d,0xff,0x01,0x04,
0x0d,0x0c,0xff,0x01,0x02,0x6e,0xff,0xfe,0x01,0x13,0xff,0x6f,0xff,0x01,0x02,0x0d,
0x0c,0xff,0x01,0x02,0x7e,0xff,0xfe,0x01,0x13,0xff,0x7f,0xff,0x01,0x02,0x0d,0x0c,
0xff,0x01,0x04,0x6c,0xfe,0x01,0x11,0x6d,0xff,0x01,0x04,0x0d,0x0c,0xff,0x01,0x1d,
0x0d,0x0c,0xff,0x01,0x07,0xf0,0xec,0xe1,0xf9,0xec,0xe9,0xf3,0xf4,0xff,0xf1,0xf5,
0xe5,0xf5,0xe5,0xff,0x01,0x07,0x0d,0x0c,0xff,0x5c,0xfe,0x01,0x19,0x5d,0xff,0x0d,
0x0c,0xff,0xfe,0x01,0x1b,0xff,0x0d,0x0c,0xff,0xfe,0x01,0x1b,0xff,0x0d,0x0c,0xff,
0xfe,0x01,0x1b,0xff,0x0d,0x0c,0xff,0xfe,0x01,0x1b,0xff,0x0d,0x0c,0xff,0xfe,0x01,
0x1b,0xff,0x0d,0x0c,0xff,0xfe,0x01,0x1b,0xff,0x0d,0x0c,0xff,0xfe,0x01,0x1b,0xff,
0x0d,0x0c,0xff,0xfe,0x01,0x1b,0xff,0x0d,0x0c,0xff,0xfe,0x01,0x1b,0xff,0x0d,0x0c,
0xff,0xfe,0x01,0x1b,0xff,0x0d,0x0c,0xff,0x6c,0xfe,0x01,0x19,0x6d,0xff,0x0d,0x0c,
0xff,0x01,0x03,0xf3,0xe5,0xec,0xe5,0xe3,0xf4,0xe0,0xff,0xf4,0xef,0xe7,0xe7,0xec,
0xe5,0xff,0xf0,0xec,0xe1,0xf9,0xec,0xe9,0xf3,0xf4,0xff,0x01,0x02,0x0d,0x0c,0xff,
0x01,0x03,0xf0,0xf2,0xe5,0xf3,0xf3,0xff,0xe1,0xff,0xf4,0xef,0xff,0xe1,0xe4,0xe4,
0xff,0xf4,0xef,0xff,0xf1,0xf5,0xe5,0xf5,0xe5,0xff,0x01,0x02,0x0d,0x0c,0xff,0x01,
0x03,0xf0,0xf2,0xe5,0xf3,0xf3,0xff,0xe2,0xff,0xf4,0xef,0xff,0xf2,0xe5,0xed,0xef,
0xf6,0xe5,0xff,0x01,0x08,0x0d,0x0c,0xff,0x01,0x03,0xf0,0xf2,0xe5,0xf3,0xf3,0xff,
0xf5,0xf0,0xff,0xf4,0xef,0xff,0xf3,0xeb,0xe9,0xf0,0xff,0xf4,0xef,0xff,0xee,0xe5,
0xf8,0xf4,0xff,0xff,0x0d,0x0a,0x0b,0x04,0x01,0x0b,0x06,0x0e,0x0e,0x07,0x04,0x01,
0x0b,0x0a,0x0b,0x02,0x02,0x05,0x01,0x0b,0x08,0x05,0x05,0x09,0x05,0x01,0x0b,0x02,
0x02,0x7f,0x5c,0x5f,0x01,0x03,0x53,0xdf,0x55,0x00,0x01,0x05,0x55,0x55,0x00,0x01,
0x05,0x55,0x11,0x00,0x01,0x05,0x44,0x11,0x00,0x01,0x05,0x44,0x11,0x00,0x01,0x05,
0x44,0x55,0x00,0x01,0x05,0x45,0x07,0x05,0x05,0x0d,0x07,0x05,0x05,0x0d,0x01,0x00
};

void unrle_bgm1() {
	vram_adr(NAMETABLE_A);
	vram_unrle(state_soundtestscreen);  
}
void unrle_bgm2() {
	vram_adr(NAMETABLE_A);
	vram_unrle(SoundQueue);  
}

CODE_BANK_POP()
CODE_BANK_PUSH("XCD_BANK_09")

#include "defines/charmap/bgm_charmap.h"
#include "music_soundTestTables.h"
#include "sfx_soundTestTables.h"








void play_next_queue() {

			for (tmp1 = 0; tmp1 < MAX_SONG_QUEUE_SIZE; tmp1++) {		
				tmp2 = tmp1 + 1;
				music_queue[tmp1] = music_queue[tmp2];
			}

			music_queue[MAX_SONG_QUEUE_SIZE] = 0xFF;

			if (music_queue[0] != 0xFF) { music_play(xbgmlookuptable[music_queue[0]]); songplaying = 1; }
			else { famistudio_music_stop(); songplaying = 0; }
				
			//refresh_queue_screen();
			tmp4 = 0xFF;
}			


void check_if_music_stopped_huge() {
	if (!queuemode) {
		if (songplaying && famistudio_song_speed == 0x80) { if (!song) music_play(xbgmlookuptable[song]); else music_play(xbgmlookuptable[song]);}
	}
	else {
		if (famistudio_song_speed == 0x80) {

			play_next_queue();

		}
	}
}	

void refresh_queue_screen() {
	switch (tmp4) {
		case 0:
		case 0xFF:
				crossPRGBankJump0(update_text2);
				tmp4 = 2;
				break;
		case 1:
				update_text3();
				tmp4 = 3;
				break;
				
		case 2:
			for (tmp1 = 2; tmp1 < 4; tmp1++) {			//limited to 5??
			one_vram_buffer_horz_repeat('$', 27, NTADR_A(3, (13 + (tmp1))));		
			if (music_queue[tmp1] != 0xFF) {
				tmp3 = music_queue[tmp1];
				__A__ = idx16_load_hi(xbgmtextsUpper, tmp3);
				if (__A__) { 
					multi_vram_buffer_horz(xbgmtextsUpper[tmp3], xbgmtextsUpperSize[tmp3], NTADR_A(3, (13 + (tmp1))));
					multi_vram_buffer_horz(xbgmtextsLower[tmp3], xbgmtextsLowerSize[tmp3], NTADR_A((4 + xbgmtextsUpperSize[tmp3]), (13 + (tmp1))));
				} else {
					multi_vram_buffer_horz(xbgmtextsLower[tmp3], xbgmtextsLowerSize[tmp3], NTADR_A(3, (13 + (tmp1))));
					one_vram_buffer_horz_repeat('$', 7, NTADR_A((3 + xbgmtextsLowerSize[tmp3]), (13 + (tmp1))));
				}				
			} else one_vram_buffer_horz_repeat('$', 27, NTADR_A(3, (13 + (tmp1))));	
			tmp4 = 1;
			}
			break;
		case 3:
			for (tmp1 = 4; tmp1 < 6; tmp1++) {			//limited to 5??
			one_vram_buffer_horz_repeat('$', 27, NTADR_A(3, (13 + (tmp1))));	
			if (music_queue[tmp1] != 0xFF) {
				crossPRGBankJump0(text_stuff);			
			}
			else one_vram_buffer_horz_repeat('$', 27, NTADR_A(3, (13 + (tmp1))));	
			tmp4 = 4;
			}
			break;
		case 4:
			for (tmp1 = 6; tmp1 < 8; tmp1++) {			//limited to 5??
			one_vram_buffer_horz_repeat('$', 27, NTADR_A(3, (13 + (tmp1))));	
			if (music_queue[tmp1] != 0xFF) {
				crossPRGBankJump0(text_stuff);			
			}
			else one_vram_buffer_horz_repeat('$', 27, NTADR_A(3, (13 + (tmp1))));	
			tmp4 = 5;
			}
			break;
		case 5:
			for (tmp1 = 8; tmp1 < 10; tmp1++) {			//limited to 5??
			one_vram_buffer_horz_repeat('$', 27, NTADR_A(3, (13 + (tmp1))));	
			if (music_queue[tmp1] != 0xFF) {
				crossPRGBankJump0(text_stuff);			
			}
			else one_vram_buffer_horz_repeat('$', 27, NTADR_A(3, (13 + (tmp1))));	
			}
			tmp4 = 0;
			break;
	};
			
}					

//CODE_BANK_POP()





void update_text1() {
	__A__ = idx16_load_hi(xbgmtextsUpper, tempsong);
	if (__A__) draw_padded_text(xbgmtextsUpper[tempsong], xbgmtextsUpperSize[tempsong], 14, NTADR_A(9, 7));
	else one_vram_buffer_horz_repeat('$', 15, NTADR_A(9, 7));
	__A__ = idx16_load_hi(xbgmtextsLower, tempsong);
	if (__A__) draw_padded_text(xbgmtextsLower[tempsong], xbgmtextsLowerSize[tempsong], 14, NTADR_A(9, 8));
	else one_vram_buffer_horz_repeat('$', 15, NTADR_A(9, 8));
	
	__A__ = idx16_load_hi(xbgmtextsLowerOrigArtist, tempsong);
	if (__A__) draw_padded_text(xbgmtextsLowerOrigArtist[tempsong], xbgmtextsLowerOrigArtistSize[tempsong], 14, NTADR_A(9, 14));
	else one_vram_buffer_horz_repeat('$', 15, NTADR_A(9, 14));
	__A__ = idx16_load_hi(xbgmtextsUpperOrigArtist, tempsong);
	if (__A__) draw_padded_text(xbgmtextsUpperOrigArtist[tempsong], xbgmtextsUpperOrigArtistSize[tempsong], 14, NTADR_A(9, 13));
	else one_vram_buffer_horz_repeat('$', 15, NTADR_A(9, 13));

	tmp5 = 1;
}	

void update_text3() {
	__A__ = idx16_load_hi(xbgmtextsUpper, tempsong);
	if (__A__) draw_padded_text(xbgmtextsUpper[tempsong], xbgmtextsUpperSize[tempsong], 14, NTADR_A(9, 7));
	else one_vram_buffer_horz_repeat('$', 15, NTADR_A(9, 7));
	__A__ = idx16_load_hi(xbgmtextsLower, tempsong);
	if (__A__) draw_padded_text(xbgmtextsLower[tempsong], xbgmtextsLowerSize[tempsong], 14, NTADR_A(9, 8));
	else one_vram_buffer_horz_repeat('$', 15, NTADR_A(9, 8));
}

void update_covering_artists() {
			__A__ = idx16_load_hi(xbgmtextsCoveringArtist1, tempsong);
			if (__A__) draw_padded_text(xbgmtextsCoveringArtist1[tempsong], xbgmtextsCoveringArtist1Size[tempsong], 14, NTADR_A(9, 19));
			else one_vram_buffer_horz_repeat('$', 15, NTADR_A(9, 19));
			__A__ = idx16_load_hi(xbgmtextsCoveringArtist2, tempsong);
			if (__A__) draw_padded_text(xbgmtextsCoveringArtist2[tempsong], xbgmtextsCoveringArtist2Size[tempsong], 14, NTADR_A(9, 20));
			else one_vram_buffer_horz_repeat('$', 15, NTADR_A(9, 20));
			__A__ = idx16_load_hi(xbgmtextsCoveringArtist3, tempsong);
			if (__A__) draw_padded_text(xbgmtextsCoveringArtist3[tempsong], xbgmtextsCoveringArtist3Size[tempsong], 14, NTADR_A(9, 21));
			else one_vram_buffer_horz_repeat('$', 15, NTADR_A(9, 21));
			__A__ = idx16_load_hi(xbgmtextsCoveringArtist4, tempsong);
			if (__A__) draw_padded_text(xbgmtextsCoveringArtist4[tempsong], xbgmtextsCoveringArtist4Size[tempsong], 14, NTADR_A(9, 22));
			else one_vram_buffer_horz_repeat('$', 15, NTADR_A(9, 22));
			tmp5 = 0;
}



void text_stuff() {
	tmp3 = music_queue[tmp1];
	__A__ = idx16_load_hi(xbgmtextsUpper, tmp3);
	if (__A__) { 
		multi_vram_buffer_horz(xbgmtextsUpper[tmp3], xbgmtextsUpperSize[tmp3], NTADR_A(3, (13 + (tmp1))));
		__A__ = idx16_load_hi(xbgmtextsLower, tmp3);
		multi_vram_buffer_horz(xbgmtextsLower[tmp3], xbgmtextsLowerSize[tmp3], NTADR_A((4 + xbgmtextsUpperSize[tmp3]), (13 + (tmp1))));
	}
	else {
		__A__ = idx16_load_hi(xbgmtextsLower, tmp3);
		multi_vram_buffer_horz(xbgmtextsLower[tmp3], xbgmtextsLowerSize[tmp3], NTADR_A(3, (13 + (tmp1))));
		one_vram_buffer_horz_repeat('$', 7, NTADR_A((3 + xbgmtextsLowerSize[tmp3]), (13 + (tmp1))));

	}	
}	

CODE_BANK_POP()
CODE_BANK_PUSH("XCD_BANK_07")


void refreshmenu();
void refreshmenu_part2();
void code_checker();
void set_fun_settings();




#include "defines/charmap/bgm_charmap.h"


void update_text2() {
	if (music_queue[0] != 0xFF) one_vram_buffer(0x9F, NTADR_A(1, 13));
	else one_vram_buffer(0xFF, NTADR_A(1, 13));
	for (tmp1 = 0; tmp1 < 2; tmp1++) {			//limited to 5??
		if (music_queue[tmp1] != 0xFF) {
			one_vram_buffer_horz_repeat('$', 27, NTADR_A(3, (13 + (tmp1))));	
			crossPRGBankJump0(text_stuff);
		}
		else one_vram_buffer_horz_repeat('$', 27, NTADR_A(3, (13 + (tmp1))));	
	}	
	//ppu_on_all();
	tmp4 = 2;
}	



void state_soundtest() {
  	famistudio_music_stop();
  	music_update();

	pal_bg(paletteMenu);

	tempsong = 0;
	temptemp6 = 0; 	
	#define sfx tmp4
	sfx = 0;
	settingvalue = 0;
//	menuMusicCurrentlyPlaying=0;
	crossPRGBankJump0(unrle_bgm1); 	
	crossPRGBankJump0(update_text1);
	
	ppu_on_all();
	pal_fade_in();
	
	while (1) {
		//rand8();
		ppu_wait_nmi();
		oam_clear();
		crossPRGBankJump0(check_if_music_stopped_huge);
		 // read the first controller
		 crossPRGBankJump0(mouse_and_cursor);
		kandoframecnt++;
		if (kandoframecnt & 1 && mouse_timer) mouse_timer--;	
		if (tmp4) crossPRGBankJump0(refresh_queue_screen);
		if (tmp5) {
				crossPRGBankJump0(update_covering_artists);
		}

	if (joypad1.press_right || joypad1.press_left || mouse.left_press) hold_timer = 0;
	if (joypad1.press_right || 
			(mouse.left_press && ((mouse.x >= 0xD6 && mouse.x <= 0xDC) && (mouse.y >= 0x34 && mouse.y <= 0x42))) || 
			(((joypad1.right || 
				(mouse.left && ((mouse.x >= 0xD6 && mouse.x <= 0xDC) && (mouse.y >= 0x34 && mouse.y <= 0x42)))) && 
			hold_timer >= 15))) { 
				tempsong++; 
				if (tempsong == song_max) {tempsong = 0;} 
				if (tempsong == 4) tempsong = 5; 
				temptemp6 = 0; 
				hold_timer = 0;
				if (!queuemode) crossPRGBankJump0(update_text1);
				else crossPRGBankJump0(update_text3);
			}
	if (joypad1.press_left || 
			(mouse.left_press && ((mouse.x >= 0x1D && mouse.x <= 0x25) && (mouse.y >= 0x34 && mouse.y <= 0x42))) || 
			(((joypad1.left || 
				(mouse.left && ((mouse.x >= 0x1D && mouse.x <= 0x25) && (mouse.y >= 0x34 && mouse.y <= 0x42)))) && 
			hold_timer >= 15))) { 	
				if (tempsong == 0) tempsong = song_max - 1;
				else tempsong--; 
				if (tempsong == 4) tempsong = 3; 
				temptemp6 = 0; 
				hold_timer = 0;
				if (!queuemode) crossPRGBankJump0(update_text1);
				else crossPRGBankJump0(update_text3);
			}

	if (!queuemode) {		//not queue mode
		if (joypad1.press_b || mouse.right_press ||
			(mouse.left_press && ((mouse.x >= 0x37 && mouse.x <= 0xAC) && (mouse.y >= 0xD3 && mouse.y <= 0xDB)))
		) {
			tmp3--;			
			one_vram_buffer(' ', NTADR_A(11, 7));
			one_vram_buffer(' ', NTADR_A(11, 14));
			//menuMusicCurrentlyPlaying = 1;
			gameState = STATE_MENU;
			return;
		}
		if (joypad1.press_a || (mouse.left_press && ((mouse.x >= 0x2E && mouse.x <= 0xCD) && (mouse.y >= 0x2B && mouse.y <= 0x4B)))) {
				song = tempsong;
				if (!temptemp6) { music_play(xbgmlookuptable[song]); temptemp6 = 1; songplaying = 1; }
				else { famistudio_music_stop(); music_update(); temptemp6 = 0; songplaying = 0; }
		}					
		if (joypad1.press_select ||
			(mouse.left_press && ((mouse.x >= 0x26 && mouse.x <= 0xDD) && (mouse.y >= 0xC3 && mouse.y <= 0xCB)))
		) { 
			ppu_off();
			crossPRGBankJump0(unrle_bgm2); 	   	
			ppu_on_all();
			queuemode = 1;
			update_text2();
			crossPRGBankJump0(update_text3);
		}
	}
	else {											//queue mode
		if (joypad1.press_select ||
			(mouse.left_press && ((mouse.x >= 0x26 && mouse.x <= 0xDD) && (mouse.y >= 0xBC && mouse.y <= 0xC3)))			//exit queue		
		) { 
			ppu_off();
			crossPRGBankJump0(unrle_bgm1);
			ppu_on_all();
			queuemode = 0;
			crossPRGBankJump0(update_text1);
		}	

		if (joypad1.press_up ||
			(mouse.left_press && ((mouse.x >= 0x0E && mouse.x <= 0xED) && (mouse.y >= 0x5A && mouse.y <= 0xB8)))
		) {
				crossPRGBankJump0(play_next_queue);		//debug
		}


		if (joypad1.press_a || (mouse.left_press && ((mouse.x >= 0x2E && mouse.x <= 0xCD) && (mouse.y >= 0x2B && mouse.y <= 0x4B)))) {
			if (music_queue[0] == 0xFF) { 
				song = tempsong;
				music_play(xbgmlookuptable[song]); 
				music_queue[0] = song;
				songplaying = 1;
				update_text2();
			}
			else {
				for (tmp1 = 1; tmp1 < MAX_SONG_QUEUE_SIZE; tmp1++) {
					if (music_queue[tmp1] == 0xFF) {
						music_queue[tmp1] = tempsong;
						break;
					}
				}
				if (music_queue[10] == 0xFF) update_text2();
			}
		}
		if (joypad1.press_b || mouse.right_press) {
			if (music_queue[0] == 0xFF) { }
			else if (music_queue[1] == 0xFF) { 
					music_queue[0] = 0xFF;
					crossPRGBankJump0(refresh_queue_screen);
					tmp4 = 2;
					famistudio_music_stop();
					songplaying = 0;
			}
			else {
				for (tmp1 = MAX_SONG_QUEUE_SIZE - 1; tmp1--; tmp1 > 0) {
					if (music_queue[tmp1] != 0xFF) {
						music_queue[tmp1] = 0xFF;
						crossPRGBankJump0(refresh_queue_screen);
						tmp4 = 2;
						break;
					}
				}
			}
		}
	}				
		
		// sound test codes
	if (hold_timer < 15) hold_timer++;	
	}
}


			


void decrement_was_on_slope() {
	if (currplayer_was_on_slope_counter) {
		currplayer_was_on_slope_counter--;
		
		if (!currplayer_was_on_slope_counter) {
			if (gamemode == GAMEMODE_CUBE || gamemode == GAMEMODE_BALL) {
				// Set carry to 1 if slope is upside down
				__A__ = (currplayer_slope_type & SLOPE_UPSIDEDOWN) + (256 - SLOPE_UPSIDEDOWN);
				__A__ = currplayer_table_idx & ~TBLIDX_GRAV;
				__asm__ ("adc #0 \n tay");
				// Thus, gravity in the table index is replaced with SLOPE_UPSIDEDOWN
				switch (gamemode) {
					case GAMEMODE_BALL:
						switch (currplayer_slope_type) {
							case SLOPE_22DEG_UP:
							case SLOPE_22DEG_UP_UD:
								currplayer_vel_y += EXIT_SLOPE_BALL_22(get_Y);
								break;
							case SLOPE_66DEG_UP:
							case SLOPE_66DEG_UP_UD:
								currplayer_vel_y += EXIT_SLOPE_BALL_66(get_Y);
						}
						break;
					case GAMEMODE_CUBE:
						switch (currplayer_slope_type) {
							case SLOPE_22DEG_UP:
							case SLOPE_22DEG_UP_UD:
								currplayer_vel_y += EXIT_SLOPE_CUBE_22(get_Y);
								break;
						}
						break;
				}
			}
			currplayer_slope_type = 0;
		}
	} else {
		currplayer_last_slope_type = 0;
		currplayer_slope_type = 0;
	}	
}


void check_practice_point_deletion() {
	if (practicebuffer || (practice_point_count > 1 && (joypad1.press_select || (mouse.left && mouse.right_press)) && !(joypad1.hold & (PAD_UP | PAD_DOWN)))) {
				curr_practice_point--;
				practicebuffer = 0;
				if (latest_practice_point) latest_practice_point--;
				if (curr_practice_point >= practice_point_count)
					curr_practice_point = practice_point_count - 1;
	}
}

void end_level_debug() {
				END_LEVEL_TIMER = 0;
				kandokidshack4 = 0;
				oam_clear();
				gameState = STATE_LVLDONE;
				//DEBUG_MODE = 0;
				famistudio_music_stop();
}				



void set_completion_data() {
	if (!DEBUG_MODE && !kandokidshack && !kandokidshack3 && !kandokidshack4) {
		if (!practice_point_count) {
			if (!invisblocks) {
				LEVELCOMPLETE[level] = 1;
				if (coins & COIN_1) coin1_obtained[level] = 1;
				if (coins & COIN_2) coin2_obtained[level] = 1;
				if (coins & COIN_3) coin3_obtained[level] = 1;
				level_completeness_normal[level] = 100;
			}
			else {
				invisible_LEVELCOMPLETE[level] = 1;
				if (coins & COIN_1) invisible_coin1_obtained[level] = 1;
				if (coins & COIN_2) invisible_coin2_obtained[level] = 1;
				if (coins & COIN_3) invisible_coin3_obtained[level] = 1;
				invisible_level_completeness_normal[level] = 100;
			}			
		} else {
			if (!invisblocks) level_completeness_practice[level] = 100;
			else invisible_level_completeness_practice[level] = 100;
		}
	}
}

void set_lvldone_palette() {
	mmc3_set_1kb_chr_bank_0(LEVELCOMPLETEBANK);
	mmc3_set_1kb_chr_bank_1(PRACTICECOMPLETEBANK);
	mmc3_set_1kb_chr_bank_2(LEVELCOMPLETEBANK+2);
	mmc3_set_1kb_chr_bank_3(LEVELCOMPLETEBANK+3);
	mmc3_set_2kb_chr_bank_1(MOUSEBANK);

	// Set palettes back to natural colors since we aren't fading back in
	pal_bright(4);
	pal_bg(paletteMenu);
	pal_col(0x0A,0x2A);
	pal_col(0x0B,0x21);
	pal_set_update();
    //pal_spr(paletteMenu);
	pal_spr(paletteDefaultSP);
}

CODE_BANK_POP()


