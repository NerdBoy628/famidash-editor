// prototype
#ifdef level_luckydraw
void Lucky_Draw_Text_Stuff();
#endif
void init_sprites();
#if !__VS_SYSTEM
	#include "defines/charmap/bg_charmap.h"
	const unsigned char attempttext[]="PQQRSTQ"; //ATTEMPT
#endif


//const unsigned char whartxt[]="wxyz";	// WHAR
void setdefaultoptions();
/* 
	Reset run-length decoder back to zero
	Implemented in asm
*/
void __fastcall__ init_rld(uint8_t level);

/* 
	This should explain itself
	Requires the correct PRG1 bank to be set
	Implemented in asm
*/
void __fastcall__ unrle_next_column();

/* 
	Scrolling to the right, draw metatiles as we go
	Returns 1 if it actually did anything
	Implemented in asm	
*/
char __fastcall__ draw_screen();

/*
	Load ground tiles into collision map
	Implemented in asm
*/
void __fastcall__ load_ground(uint8_t id);

/*
	Dummy unrle columns, way faster
	Implemented in asm
*/
void __fastcall__ dummy_unrle_columns(uint16_t columns);

void increase_parallax_scroll_column() {
	// The parallax is a 6 x 9 tile background, and when it repeats
	// horizontally, we offset the start of the next column by 3
	// to stagger the repeat
	parallax_scroll_column++;
	if (parallax_scroll_column >= 6) {
		parallax_scroll_column = 0;
		parallax_scroll_column_start += 3;
		if (parallax_scroll_column_start >= 9) {
			parallax_scroll_column_start = 0;
		}
	}
}

extern unsigned char drawing_frame;
void unrle_first_screen(){ // run-length decode the first screen of a level
	// register unsigned char i;
	#define i (*((uint8_t *)&ii))
	register uint16_t ii;
	mmc3_set_prg_bank_1(GET_BANK(increment_attempt_count));
	#if !__VS_SYSTEM
		increment_attempt_count();
	#else
		memfill(attemptCounter, 0, sizeof(attemptCounter));
		for (tmp2 = 0; tmp2 < coins_inserted; tmp2++) {
			increment_attempt_count();
		}
	#endif



	mmc3_set_prg_bank_1(level_data_bank);



	// If practice mode has set a scroll position to restart from
	// Then we dummy unrle, and adjust the parallax to match
	if (practice_point_count) {

		ii = lohi_arr32_load(practice_scroll_x, curr_practice_point) >> 4;
		dummy_unrle_columns(ii);

		__A__ = -(6 * (9 / 3) / 2); __asm__("tay \n sty %v", parallax_scroll_column);
		while (ii != 0) {
			parallax_scroll_column++;
			if (parallax_scroll_column == 0) {
				__asm__("sty %v", parallax_scroll_column);
			}
			ii--;
		}
		parallax_scroll_column_start = -3;
		__asm__("ldy #3");
		unrle_first_screen_addition_loop:
			__asm__("tya ");
			parallax_scroll_column_start += __A__;
			__asm__("tya ");
			parallax_scroll_column += __A__;
			__asm__("bmi %g", unrle_first_screen_addition_loop);
		parallax_scroll_column <<= 1;

		crossPRGBankJump0(load_practice_state);	

		mmc3_set_prg_bank_1(GET_BANK(draw_screen));
		// Draw the nametable starting from where the scroll is set
		i = -16;
		do {
			if (draw_screen()) flush_vram_update2();	// if draw_screen did anything, flush vram
			i++;
			uint32_inc(scroll_x);
		} while (i != 0);
	} 
	else {
		// To get the draw screen R to start in the left nametable, scroll must be negative.
		low_word(scroll_x) = LSW(-256); high_word(scroll_x) = MSW(-256);
		parallax_scroll_x = 0;
		parallax_scroll_column = 0;
		parallax_scroll_column_start = 0;
		i = 0;
		mmc3_set_prg_bank_1(GET_BANK(draw_screen));
	}
	

	// Draw the nametable starting from where the scroll is set
    do {
		if (draw_screen()) flush_vram_update2();	// if draw_screen did anything, flush vram
		i++;
		uint32_inc(scroll_x);
	} while (i != 0);

//	level_resetting_flag = 2;
//	if (!level_resetting_flag) timewarp_done = 0;   how was this a fix? this cant ever be false...

	init_sprites();
	
	set_scroll_x(scroll_x);
	set_scroll_y(scroll_y);
//	if (!practice_point_count) {
		#if !__VS_SYSTEM
			multi_vram_buffer_horz((const char*)attempttext,sizeof(attempttext)-1,NTADR_C(6, 15));
		#endif
	
			#ifdef level_luckydraw
			
			crossPRGBankJump0(Lucky_Draw_Text_Stuff);

			#endif
			
			mmc3_set_prg_bank_1(GET_BANK(_display_attempt_counter));
			display_attempt_counter(0xF5, NTADR_C(20, 15));
			
			
//	}
	
}
