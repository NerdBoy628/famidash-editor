// To be merged into levelselection.c

const uint8_t difficulty_pal_A[];
const uint8_t difficulty_pal_B[];
const uint8_t difficulty_pal_C[];
const uint8_t difficulty_pal_D[];

#include "defines/charmap/color1_charmap.h"
#include "menutext.h"

const char coin_counter[][3];

/*
	Refreshes level name & number
*/
const unsigned char invisibletext[9]="INVISIBLE";

void refreshmenu() {
	tmp5 = ((level&1)<<2)<<8;	// Which nametable to put the data into
	set_scroll_x(((level-tmp4)&1)<<8);
	
	if (invisblocks) { multi_vram_buffer_horz((const char*)invisibletext,sizeof(invisibletext),NTADR_A(12, 9));	
	multi_vram_buffer_horz((const char*)invisibletext,sizeof(invisibletext),NTADR_B(12, 9)); }
	
	__A__ = idx16_load_hi(levelTextsUpper, level);
	if (__A__) draw_padded_text(levelTextsUpper[level], levelTextsUpperSize[level], 17, NTADR_A(8, 10)|(tmp5 & 0xFF00));
	else one_vram_buffer_horz_repeat(' ', 17, NTADR_A(8, 10)|(tmp5 & 0xFF00));
	// if (leveltexts2[level]) // always true
	draw_padded_text(levelTextsLower[level], levelTextsLowerSize[level], 17, NTADR_A(8, 11)|(tmp5 & 0xFF00));

	if (invisblocks ? invisible_LEVELCOMPLETE[level] : LEVELCOMPLETE[level]) { one_vram_buffer('y', NTADR_A(7, 9)|(tmp5 & 0xFF00));
	one_vram_buffer('z', NTADR_A(8, 9)|(tmp5 & 0xFF00)); }
	else one_vram_buffer_horz_repeat(' ', 2, NTADR_A(7, 9)|(tmp5 & 0xFF00));

	{	// write the difficulty
		tmp1 = difficulty_list[level];
		if (stars_list[level] == 10 && level > 25) {
			mmc3_set_1kb_chr_bank_2(DEMONFACE_HUGE_BANK);
			pal_col(0x0a, difficulty_pal_C[tmp1]);
			pal_col(0x0b, difficulty_pal_D[tmp1]);
		}
		else {
			mmc3_set_1kb_chr_bank_2(DIFFICULTY_FACE_BANK);
			pal_col(0x0a, difficulty_pal_A[tmp1]);
			pal_col(0x0b, difficulty_pal_B[tmp1]);
		}
		pal_set_update();
		
		tmp1 = (tmp1 << 1) + 'a';
		one_vram_buffer(tmp1, NTADR_A(7, 10)|(tmp5 & 0xFF00));
		one_vram_buffer(++tmp1, NTADR_A(8, 10)|(tmp5 & 0xFF00));
		one_vram_buffer((tmp1 += ('c'-'b')), NTADR_A(7, 11)|(tmp5 & 0xFF00));
		one_vram_buffer(++tmp1, NTADR_A(8, 11)|(tmp5 & 0xFF00));
		

	}
	// Star count stuff
		printDecimal(stars_list[level], 2, '0', ' ', NTADR_A(22, 9)|(tmp5 & 0xFF00));

	// level number
	#ifdef FLAG_ENABLE_TEST_LEVELS
		printDecimal(level, 3, '0', ' ', NTADR_A(29, 2));
		printDecimal(level, 3, '0', ' ', NTADR_B(29, 2));
	#endif

	//palette stuff
		tmp3 = level % 9;
		pal_col(0,colors_list[tmp3]);
		pal_col(0xE,colors_list[tmp3]);
		
		pal_spr(paletteLVLSelectSP);
		pal_col(0x10,colors_list[tmp3]);
		pal_col(0x1E,colors_list[tmp3]);
		pal_set_update();
	//coin stuff
		coins = 0;

	// then in the function...
	// combine all three into a single number from 0 - 7 to represent which coins have been grabbed
		if (!invisblocks) tmp7 = byte((byte(coin3_obtained[level] << 1) | coin2_obtained[level]) << 1) | coin1_obtained[level];
		else tmp7 = byte((byte(invisible_coin3_obtained[level] << 1) | invisible_coin2_obtained[level]) << 1) | invisible_coin1_obtained[level];
		tmp7 = byte(tmp7<<1) + tmp7;
	// actually draw the coins
		multi_vram_buffer_horz((const char * const)coin_counter+tmp7, 3, NTADR_A(22, 12)|(tmp5 & 0xFF00));

}

	const uint8_t difficulty_pal_A[] ={
		0x21,	// easy
		0x2A,	// normal
		0x28,	// hard
		0x16,	// harder
		0x24,	// insane
		0x16,	// demon
		0x28,	// auto
	};

	const uint8_t difficulty_pal_B[] ={
		0x06,	// easy
		0x30,	// normal
		0x30,	// hard
		0x30,	// harder
		0x06,	// insane
		0x30,	// demon
		0x21,	// auto
	};
	
	const uint8_t difficulty_pal_C[] ={
        0x13,    // easy demon
        0x14,    // medium demon
        0x16,    // hard demon
        0x16,    // insane demon
        0x06,    // extreme demon
        0x06,    // impossible demon
        0x03,    // grandpa demon
	};

	const uint8_t difficulty_pal_D[] ={
		0x30,	// easy demon
		0x30,	// medium demon
		0x30,	// hard demon
		0x30,	// insane demon
		0x30,	// extreme demon
		0x30,	// impossible demon
		0x30,	// grandpa demon
	};

const char coin_counter[][3] = {
  "___",
  "^__",
  "_^_",
  "^^_",
  "__^",
  "^_^",
  "_^^",
  "^^^",
};

